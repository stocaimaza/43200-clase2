/* SUGAR SYNTAX */

//¿QUÉ ES? La utilización de operadores avanzados con la idea de simplificar código. 

//1) Plantillas literales: las usamos a traves de las backsticks `` y me permite simplificar la concatenación de datos. 

let variableNombre = "Samuel";
console.log("hola soy " + variableNombre);

`` //backsticks

//alt + 96  pueden generarlas con esta combinación de teclas. 

let nombre = "Pepe Argento";
let trabajo = "Zapatería"; 

let mensaje = `${nombre} trabaja en una ${trabajo}`;

console.log(mensaje);

//2) Operador Ternario: Es una simplificación de la estructura if/else. 

//SINTAXIS: condicion ? codigoSiEsVerdad : codigoSiEsFalso

let llueve = false; 

console.log(llueve ? "tortas fritas y netflix" : "hacemos un asado");

//3) Operador Spread: Operador de propagación. 
//Se utiliza en elementos iterables (arrays, objetos) enviando cada uno de sus elementos como parámetros a una función. 

const nombres = ["Juan", "Pedro", "Maria", "Jose"]; 

console.log(nombres);

//Si utilizo el operador spread: 

console.log(...nombres);

console.log(nombres[0], nombres[1], nombres[2], nombres[3]);

//Copiar objetos: 

const alumno = {
    nombre:"Coki",
    apellido: "Argento",
    edad: 42
}

//const alumnoDos = alumno;
//Esto no se puede hacer!!
//Si hago esto estoy copiando la referencia en memoria. 

//Para copiar objetos de forma correcta tenemos que utilizar el operador SPREAD: 

const alumnoTres = {...alumno};

console.log("Vemos al alumno 3: ");
console.log(alumnoTres);

//Copiamos Arrays: 

const a = [1, 2, 3];
const b = [4, 5, 6];

const nuevoArray = [...a, ...b];
console.log(nuevoArray);
/*
"" //Comillas dobles
'' //Comillas simples
`` //Backsticks
*/
//4) Desestructuración de objetos: Es una expresión de JS que permite desempaquetar valores de arrays u objetos en distintas variables. 

//Ejemplo: 

const bart = {
    nombre:"Bart",
    apellido: "Simpson",
    edad: 10, 
    escuela: "Sprinfield Elementary School"
}; 

//Sintaxis: 

let {nombre:nombreObjeto, apellido, edad, escuela} = bart;

console.log(nombreObjeto);
console.log(escuela);

//5) Desestructuración de arrays: 

let frutas = ["Manzana", "Pera", "Naranja", "Vino"];

let [,, fruta3, fruta4] = frutas;

console.log(fruta4);

//6) Acceso Condicional a Propiedades de un objeto. 
//Lo utilizo como una herramienta para controlar errores y evitar que se rompa la aplicación.

const empleado = null;

console.log(empleado?.nombre);

//7) Operador && AND. 
//Lo usamos en las evaluaciones booleanas: 

console.log("Operador && AND"); 

let dia = "Sabado";
let curso = "React";

if(dia === "Sabado" && curso === "React") {
    console.log("Hoy estamos aprendiendo Sugar Syntax");
}

//También lo puedo utilizar como un condicional IF: 

let aprobado = false;

aprobado && console.log("Seguis estudiando en BackEnd");
//Si la condición es verdadera, ejecuto el código después del operador. 


//8) Operador OR || 

aprobado || console.log("Tendras que recursar React!");

//Atentos porque esto lo usamos mucho en React en "Renderizado Condicional".












